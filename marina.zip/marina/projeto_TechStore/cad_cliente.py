import tkinter as tk
from tkinter import messagebox, Frame, Radiobutton, IntVar
import sqlite3

class CadClientes:
    def __init__(self, root):
        self.root = root
        self.root.title("Cadastro clientes TechStore")
        self.root.geometry("400x400")

        # Configuração da conexão com o banco de dados
        self.conn = sqlite3.connect("techstore.db")
        self.cursor = self.conn.cursor()
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS usuarios (
                id INTEGER PRIMARY KEY,
                nome TEXT,
                email TEXT UNIQUE,
                senha TEXT,
                tipo TEXT,
                ativo TEXT


            )
        """)


        self.nome_label = tk.Label(root, text="Nome:")
        self.nome_label.pack()
        self.nome_entry = tk.Entry(root, width=30)
        self.nome_entry.pack()

        self.email_label = tk.Label(root, text="Email:")
        self.email_label.pack()
        self.email_entry = tk.Entry(root, width=30)
        self.email_entry.pack()

        self.senha_label = tk.Label(root, text="Senha:")
        self.senha_label.pack()
        self.senha_entry = tk.Entry(root, width=30)
        self.senha_entry.pack()

        self.tipo_label = tk.Label(root, text="Tipo:")
        self.tipo_label.pack()
        self.tipo_entry = tk.Entry(root, width=30)
        self.tipo_entry.pack()


        self.frame_cima = Frame(root)
        self.frame_cima.pack()

        # Botões de rádio para seleção de cliente ativo
        self.radio_valor = IntVar()
        self.radio_valor.set(1)  # Definir seleção padrão

        self.label = tk.Label(self.frame_cima, text='O cliente está ativo?')
        self.label.pack(anchor='w')
        self.sim = Radiobutton(self.frame_cima, text='Sim', variable=self.radio_valor, value=1)
        self.sim.pack(anchor='w')
        self.nao = Radiobutton(self.frame_cima, text='Não', variable=self.radio_valor, value=2)
        self.nao.pack(anchor='w')

        self.cadastro_button = tk.Button(root, text="Cadastrar", command=self.cadastro)
        self.cadastro_button.pack(pady=5)

    def cadastro(self):
        nome = self.nome_entry.get()
        email = self.email_entry.get()
        senha = self.senha_entry.get()
        tipo = self.tipo_entry.get()
        ativo = self.radio_valor.get()

        if len(nome.strip()) == 0 or len(email.strip()) == 0 or len(senha.strip()) == 0 or len(tipo.strip()) == 0:
            messagebox.showinfo("TechStore Cadastro de Clientes", "Todos os campos são obrigatórios")
            return
        else:
            try:
                #hashed_senha = self.hash_password(senha)
                self.cursor.execute(
                    "INSERT INTO usuarios (nome, email, senha, tipo, ativo) VALUES (?, ?, ?, ?, ?)", (nome, email, senha, tipo, ativo)
                )
                self.conn.commit()
                messagebox.showinfo("TechStore Cadastro De Clientes", "Cliente cadastrado com sucesso!")
            except sqlite3.IntegrityError:
                messagebox.showerror("TechStore Cadastro de Clientes", "Cliente já cadastrado.")

if __name__ == "__main__":
    root = tk.Tk()
    loginsystem = CadClientes(root)
    root.mainloop()
