import tkinter as tk
from tkinter import messagebox, Frame, Radiobutton, IntVar
import sqlite3
import hashlib

class LoginSystem:
    def __init__(self, root):
        self.root = root
        self.root.title("Cadastro produtos TechStore")
        self.root.geometry("400x400")

        # Configuração da conexão com o banco de dados
        self.conn = sqlite3.connect("techstore.db")
        self.cursor = self.conn.cursor()
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS produtos (
                id INTEGER PRIMARY KEY,
                nomeproduto TEXT,
                preco TEXT UNIQUE,
                cor TEXT,
                tipo TEXT,
                ativo TEXT,
                marca TEXT

            )
        """)


        self.nomeproduto_label = tk.Label(root, text="Nome do produto:")
        self.nomeproduto_label.pack()
        self.nomeproduto_entry = tk.Entry(root, width=30)
        self.nomeproduto_entry.pack()

        self.preco_label = tk.Label(root, text="Preço:")
        self.preco_label.pack()
        self.preco_entry = tk.Entry(root, width=30)
        self.preco_entry.pack()

        self.cor_label = tk.Label(root, text="Cor:")
        self.cor_label.pack()
        self.cor_entry = tk.Entry(root, width=30, show="*")
        self.cor_entry.pack()

        self.tipo_label = tk.Label(root, text="Tipo:")
        self.tipo_label.pack()
        self.tipo_entry = tk.Entry(root, width=30)
        self.tipo_entry.pack()

        self.marca_label = tk.Label(root, text="Marca:")
        self.marca_label.pack()
        self.marca_entry = tk.Entry(root, width=30)
        self.marca_entry.pack()


        self.frame_cima = Frame(root)
        self.frame_cima.pack()

        # Botões de rádio para seleção de cliente ativo
        self.radio_valor = IntVar()
        self.radio_valor.set(1)  # Definir seleção padrão

        self.label = tk.Label(self.frame_cima, text='O produto está ativo?')
        self.label.pack(anchor='w')
        self.sim = Radiobutton(self.frame_cima, text='Sim', variable=self.radio_valor, value=1)
        self.sim.pack(anchor='w')
        self.nao = Radiobutton(self.frame_cima, text='Não', variable=self.radio_valor, value=2)
        self.nao.pack(anchor='w')


        self.login_button = tk.Button(root, text="Login", command=self.login)
        self.login_button.pack(pady=5)
        self.cadastro_button = tk.Button(root, text="Cadastrar", command=self.cadastro)
        self.cadastro_button.pack(pady=5)

    def hash_password(self, password):
        return hashlib.sha256(password.encode()).hexdigest()

    def login(self):
        nomeproduto = self.nomeproduto_entry.get()
        preco = self.preco_entry.get()
        self.cursor.execute("SELECT * FROM usuarios WHERE nomeproduto=? AND preco=?", (nomeproduto, preco ))
        usuario = self.cursor.fetchone()
        if usuario:
            messagebox.showinfo("Login", f"Produto cadastrado com sucesso, {usuario[1]}!")  # usuario[1] é o nome
            self.root.destroy()  # Fecha a janela de login
        else:
            messagebox.showerror("Login", "Informações preenchidas incorretamente.")

    def cadastro(self):
        nomeproduto = self.nomeproduto_entry.get()
        preco = self.preco_entry.get()
        cor = self.cor_entry.get()
        tipo = self.tipo_entry.get()
        marca = self.marca_entry.get()

        if len(nomeproduto.strip()) == 0 or len(preco.strip()) == 0 or len(cor.strip()) == 0 or len(tipo.strip()) == 0  or len(marca.strip()) == 0:
            messagebox.showinfo("Sistema de Login", "Todos os campos são obrigatórios")
            return

        try:
            self.cursor.execute(
                "INSERT INTO produtos (nomeproduto, preco, cor, tipo, marca) VALUES (?, ?, ?, ?, ?)", (nomeproduto, preco, cor, tipo, marca)
            )
            self.conn.commit()
            messagebox.showinfo("Sistema de Login", "Produto cadastrado com sucesso!")
        except sqlite3.IntegrityError:
            messagebox.showerror("Sistema de Login", "Produto já cadastrado.")

if __name__ == "__main__":
    root = tk.Tk()
    loginsystem = LoginSystem(root)
    root.mainloop()