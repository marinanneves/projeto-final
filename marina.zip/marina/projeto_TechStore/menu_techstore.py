import tkinter as tk
from tkinter import *
import cad_cliente
import lista_prod
import cadastroprod_Techstore
import lista_techstore
# import os


class MeuMenu:
    def clientes(self):
        tela2 = tk.Tk()
        clientes = cad_cliente.CadClientes(tela2)
        tela2.mainloop()

    def listaclientes(self):
        tela2 = tk.Tk()
        clientes = lista_techstore.Liste(tela2)
        tela2.mainloop()

    def __init__(self, tela):
        self.tela = tela
        self.titulo = "Menu"
        self.tela.title(self.titulo)
        # self.tela.iconbitmap(varGlobal.IconePadrao)
        self.tela.geometry("300x200")
        self.barraDeMenus=Menu(self.tela)
        self.menuCadastros=Menu(self.barraDeMenus, tearoff=0)
        self.menuCadastros.add_command(label="Clientes", command=self.clientes)
        self.menuCadastros.add_command(label="Produtos", command=self.clientes)
        self.menuCadastros.add_separator()
        self.menuCadastros.add_command(label="Fechar", command=self.tela.quit)
        self.barraDeMenus.add_cascade(label="Cadastros", menu=self.menuCadastros)

        self.menuManutencao = Menu(self.barraDeMenus, tearoff=0)
        self.menuManutencao.add_command(label="Lista Produtos", command=self.clientes)
        self.menuManutencao.add_command(label="Lista Clientes", command=self.listaclientes)
        self.barraDeMenus.add_cascade(label="Manutenção", menu=self.menuManutencao)

        self.tela.config(menu=self.barraDeMenus)

if __name__ == "__main__":
    tela = tk.Tk()
    meumenu = MeuMenu(tela)
    tela.mainloop()