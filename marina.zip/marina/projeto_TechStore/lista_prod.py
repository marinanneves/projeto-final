import tkinter as tk
from tkinter import ttk
import sqlite3

class Liste:
       def __init__(self, tela):
        self.tela = tela
        titulo = "Lista produtos TechStore"
        self.tela.title(titulo)
        self.tela.geometry("600x200")

        # Conexão com o banco de dados
        self.conn = sqlite3.connect("techstore.db")
        self.cursor = self.conn.cursor()

        # Buscando os dados
        self.cursor.execute("SELECT * FROM produtos")
        tot_produtos = self.cursor.fetchall()
        self.conn.close()

        # Configurando a Treeview
        self.tree = ttk.Treeview(self.tela, columns=("ID", "Nome produto", "Preco", "Cor", "Tipo", "Marca"), show="headings")
        self.tree.heading("ID", text="ID")
        self.tree.heading("Nome produto", text="Nome produto")
        self.tree.heading("Preco", text="Preço")
        self.tree.heading("Cor", text="Cor")
        self.tree.heading("Tipo", text="Tipo")
        self.tree.heading("Marca", text="Marca")

        # Inserindo os dados na Treeview
        for produtos in tot_produtos:
            self.tree.insert("", tk.END, values=produtos)

        self.tree.pack()

if __name__ == "__main__":
    tela= tk.Tk()
    lista=Liste(tela)
    tela.mainloop()