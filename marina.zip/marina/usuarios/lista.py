import tkinter as tk
from tkinter import *
import sqlite3

class Liste:
    def __init__(self, tela):
        self.tela = tela
        titulo = "Sistema de Alunos - Pesquisa Alunos"
        self.titulo = titulo
        self.tela.tittle(titulo)
        self.tela.geometry("600x200")
        self.conn = sqlite3.connect("usuarios.db")
        self.conn = sqlite3.conn.cursor()
        self.cursor.execute("SELECT * FROM usuarios")
        tot_usuarios = self.cursor.fetchall()
        self.conn.close()

        self.tree = tk.Treeview(self.tela, colums =("ID", "Nome", "Email", "Senha"), sho= "headings")
        self.tree.heading("ID", text="ID")
        self.tree.heading("Nome", text="Nome")
        self.tree.heading("Email", text="Email")
        self.tree.heading("Senha", text="Senha")
        
        for count_usuario in tot_usuarios:
            self.tree.insert("", tk.END, values=count_usuario)
            
        self.tree.pack()
        
if __name__ == "__main__":
    tela= tk.Tk()
    lista=Liste(tela)
    tela.mainloop()