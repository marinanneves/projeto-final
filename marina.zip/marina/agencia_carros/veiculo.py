import tkinter as tk
from tkinter import messagebox
import sqlite3

class Agencia:
    def __init__(self, tela):
        self.tela = tela
        titulo = "Sistema de veículos"
        self.titulo =  titulo
        self.tela.title(self.titulo)
        self.tela.geometry("300*200")
        self.conn = sqlite3.connect("consorcioveiculos.bd")
        self.cursor = self.conn.cursor()
        self.cursor.execute("""CREATE TABLE IF NOT EXISTS veiculos(
                                    ID INTEGER PRIMARY KEY,
                                    nomecarro TEXT,
                                    tipo TEXT.
                                    valor TEXT,
                                    marcacarro TEXT""")
        self.nomecarrolabel = tk.Label(tela, text=" Nome do carro: ")
        self.nomecarrolabel.pack()
        self.nomecarroentry = tk.Entry(tela, width=30)
        self.nomecarroentry.pack()
        self.tipolabel = tk.Label(tela, text=" Tipo do carro: ")
        self.tipolabel.pack()
        self.tipoentry = tk.Entry(tela, width=30)
        self.tipoentry.pack()
        self.valorlabel = tk.Label(tela, text=" Valor: ")
        self.valorlabel.pack()
        self.valorentry = tk.Entry(tela, width=30)
        self.valorentry.pack()
        self.marcacarrolabel = tk.Label(tela, text=" Marca do carro: ")
        self.marcacarrolabel.pack()
        self.marcacarroentry = tk.Entry(tela, width=30)
        self.marcacarroentry.pack()
        self.verificarbutton = tk.Button(tela, text="Verificar", command=self.verificar())
        self.verificarbutton.pack()
        self.cadastrarbutton(tela, text="Cadastrar", command=self.cadastrar())
        self.cadastrarbutton.pack()

    def verificar(self):
        nomecarro = self.nomecarroentry.get()
        tipo = self.tipoentry.get()
        valor = self.valorentry.get()
        marcacarro = self.marcacarroentry.get()

        if nomecarro and tipo and valor and marcacarro:
            self.cursor.execute("SELECT*FROM veiculos WHERE nomecarro=? AND marcacarro=?", (nomecarro, marcacarro))
            veiculo = self.cursor.fetchone()
            if veiculo:
                messagebox.showinfo(self.titulo, "Esse veículo já existe")
            else:
                self.cursor.execute("INSERT INTO veiculos (nomecarro, marcacarro) VALUES (?,?)", (nomecarro, marcacarro))

if __name__ == "__main__":
    tela= tk.Tk()
    agencia= Agencia(tela)
    tela.mainloop()