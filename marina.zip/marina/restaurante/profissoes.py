import tkinter as tk
from tkinter import messagebox
import sqlite3

class Cadastro:
    def __init__(self, tela):
        self.tela=tela
        titulo="Cadastro de profissoes"
        self.titulo=titulo
        self.tela.title(self.titulo)
        self.tela.geometry("300x200")
        self.conn=sqlite3.connect("restaurante.db")
        self.cursor=self.conn.cursor()
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS profissoes(
                             cod INTEGER PRIMARY KEY,
                             nome TEXT,
                             ativo TEXT)'''
                             )
        self.nomelabel=tk.Label(tela, text="Nome")
        self.nomelabel.pack()
        self.nomeentry=tk.Entry(tela, width=30)
        self.nomeentry.pack()
        self.ativolabel=tk.Label(tela, text="Ativo")
        self.ativolabel.pack()
        self.ativoentry=tk.Entry(tela, width=30)
        self.ativoentry.pack()
        self.cadastrarbutton= tk.Button(tela, text="Cadastrar", command=self.cadastrar)
        self.cadastrarbutton.pack()

    def cadastrar(self):
        nome=self.nomeentry.get()
        ativo=self.ativoentry.get()
        self.cursor.execute("SELECT * FROM profissoes WHERE nome=? AND ativo=?",(nome, ativo))
        status=self.cursor.fetchone()

        if status:
            messagebox.showinfo(self.titulo, "Essa profissao ja existe :(")
        else:
            self.cursor.execute("INSERT INTO profissoes (nome, ativo) VALUES(?,?)", (nome, ativo))
            self.conn.commit()
            status=self.cursor.fetchone()
            messagebox.showinfo(self.titulo, "A profissao foi cadastrada com sucesso!!!")

if __name__=="__main__":
    tela=tk.Tk()
    cadastro=Cadastro(tela)
    tela.mainloop()