import tkinter as tk
from tkinter import messagebox
import sqlite3

class Cadastro:
    def __init__(self, tela):
        self.tela=tela
        titulo="Cadastro de clientes"
        self.titulo=titulo
        self.tela.title(self.titulo)
        self.tela.geometry("300x200")
        self.conn=sqlite3.connect("restaurante.db")
        self.cursor=self.conn.cursor()
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS clientes(
                             cod INTEGER PRIMARY KEY,
                             nome TEXT,
                             datanasc DATE,
                             ativo TEXT,
                             cpf VARCHAR)'''
                             )
        self.nomelabel=tk.Label(tela, text="Nome completo")
        self.nomelabel.pack()
        self.nomeentry=tk.Entry(tela, width=30)
        self.nomeentry.pack()
        self.datanasclabel = tk.Label(tela, text="Data de nascimento")
        self.datanasclabel.pack()
        self.datanascentry = tk.Entry(tela, width=30)
        self.datanascentry.pack()
        self.ativolabel=tk.Label(tela, text="Ativo")
        self.ativolabel.pack()
        self.ativoentry=tk.Entry(tela, width=30)
        self.ativoentry.pack()
        self.cpflabel = tk.Label(tela, text="CPF")
        self.cpflabel.pack()
        self.cpfentry = tk.Entry(tela, width=30)
        self.cpfentry.pack()
        self.cadastrarbutton= tk.Button(tela, text="Cadastrar cliente", command=self.cadastrar)
        self.cadastrarbutton.pack()

    def cadastrar(self):
        nome=self.nomeentry.get()
        ativo=self.ativoentry.get()
        self.cursor.execute("SELECT * FROM clientes WHERE nome=? AND datanasc=? AND ativo=? AND cpf=? ",(nome, datanasc, ativo, cpf))
        cliente=self.cursor.fetchone()

        if cliente:
            messagebox.showinfo(self.titulo, "Esse cliente ja esta cadastrado :(")
        else:
            self.cursor.execute("INSERT INTO clientes (nome, datanasc, ativo, cpf) VALUES(?,?,?,?)", (nome, datanasc, ativo, cpf))
            self.conn.commit()
            cliente=self.cursor.fetchone()
            messagebox.showinfo(self.titulo, "O cliente foi cadastrado com sucesso!!!")

if __name__=="__main__":
    tela=tk.Tk()
    cadastro=Cadastro(tela)
    tela.mainloop()