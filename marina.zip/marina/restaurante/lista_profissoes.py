import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3

class Lista: 
  def __init__(self, tela):
    self.tela = tela
    titulo = "Sistema de Usuários - pesquisas"
    self.titulo = titulo
    self.tela.tittle(titulo)
    self.tela.geometry("600x300")
    self.conn = sqlite3.connect("restaurante.db")
    self.cursor = self.conn.cursor()
    self.cursor.execute("SELECT * FROM profissoes")
    tot_profissoes = self.cursor.fetchall()
    self.conn.close()
    self.tree = ttk.Treeview(self.tela, columns = ("ID", "Nome", "Ativo", show = "headings"))
    self.tree.heading("ID", text = "ID")
    self.tree.heading("Nome", text = "Nome")
    self.tree.heading("Ativo", text = "Ativo")
    for cont_profissao in tot_profissoes:
      self.tree.insert("", tk.End, values = cont_profissao)
    self.tree.pack()
    